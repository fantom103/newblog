<?php

namespace Framework\Container;

class ServiceNotFoundException extends \InvalidArgumentException
{

}
