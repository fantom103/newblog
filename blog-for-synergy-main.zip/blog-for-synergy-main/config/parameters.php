<?php

return [
    'debug' => true,
    'users' => [
        'admin' => 'password',
    ],
];
